#include "reg52.h"
#include "Timer1.h"

unsigned char Counter1,Counter2,Compare1,Compare2;
sbit Motor1=P2^2;
sbit Motor11=P2^3;
sbit Motor2=P2^4;
sbit Motor22=P2^5;

void Motor_Init(void)
{
   Timer1Init();
}
void Motor_SetSpeed1(unsigned char Speed1)
{
     Compare1=Speed1;
}

void Motor_SetSpeed2(unsigned char Speed2)
{
     Compare2=Speed2;
}



void Time1_Routine() interrupt 3
{      
	     TL1 = 0x9C;		
     	 TH1= 0xFF;	
	     Counter1++;
	     Counter1%=100;
	
	     Counter2++;
	     Counter2%=100;
	     if(Counter1<Compare1){Motor1=0;}
			 else{Motor1=1;}
			 
			 if(Counter2<Compare2){Motor2=0;}
			 else{Motor2=1;}
}