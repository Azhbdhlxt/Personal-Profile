#ifndef __MOTOR_H__
#define __MOTOR_H__

void Motor_Init(void);
void Motor_SetSpeed1(unsigned char Speed1);
void Motor_SetSpeed2(unsigned char Speed2);
#endif