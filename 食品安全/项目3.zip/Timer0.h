#ifndef __TIMER0_H__
#define __TIMER0_H__

void Timer0_Init(void);		//500微秒@11.0592MHz

#endif