#include "regx52.h"
#include "Timer0.h"
#include "Key.h"
#include "Motor.h"
#include<intrins.h>


#define uchar unsigned char
#define uint  unsigned int


sbit Out0=P0^6;
sbit Out1=P0^7;
unsigned char flag_motor,flag_motor1,hc;
static unsigned char Angle0=0,Counter=0,Counter3=0,Angle1=0;
unsigned  int Count_Motor,Count_Motor1;
uchar receive_data;
unsigned char flag0=0,flag1=0,KeyNum;
void Contral_SetAngle0(float JIAODU0);
void Contral_SetAngle1(float JIAODU1);


	
void main(void)
{
	 Timer0_Init();
	 Motor_Init();
  
	hc=0;
	 Contral_SetAngle0(0);
	 Contral_SetAngle1(0); 
   while(1)
	 {
		 KeyNum=Key();
		if(P0_4==0&&hc==0)
		{
			flag0=1; 
	
		}
		else
		 {
		 Contral_SetAngle0(0);
			Motor_SetSpeed1(0);		 
		 }
		if(P0_5==1&&hc==0)
		{
			flag1=1;
		
		}
		else
		{
     Contral_SetAngle1(0);
			Motor_SetSpeed2(0);		 
		}
		 if(flag0==1)
		 {			 
			 Contral_SetAngle0(90);
			 if(flag_motor==1)
			 Motor_SetSpeed1(20);		 
		 }	
	  if(flag1==1)
		{		
       Contral_SetAngle1(90); 			
			if(flag_motor1==1)
			Motor_SetSpeed2(20);
		}   
		
	}
}

void Contral_SetAngle0(float JIAODU0)
{
    Angle0=JIAODU0/180*4+1;
}

void Contral_SetAngle1(float JIAODU1)
{
    Angle1=JIAODU1/180*4+1;
}


void Time0_Routine() interrupt 1
{
    TL0 = 0x33;		
	  TH0 = 0xFE;
	  Counter++;
	  Counter3++;
	  if(flag0==0)Count_Motor=0;
	  if(flag0==1)
		{
		   Count_Motor++;
			 if(Count_Motor>6000)flag_motor=1;
		}
		
			  if(flag1==0)Count_Motor1=0;
	  if(flag1==1)
		{
		   Count_Motor1++;
			 if(Count_Motor1>6000)flag_motor1=1;
		}

		 Counter%=40;
		 Counter3%=40;
		if(Counter<Angle0)Out0=1;
		else Out0=0;
		
		if(Counter3<Angle1)Out1=1;
		else Out1=0;
}


