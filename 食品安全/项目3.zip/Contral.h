#ifndef __CONTRAL_H__
#define __CONTRAL_H__

extern unsigned char flag_motor,flag_motor1;
void Contral_Init(void);
void Contral_SetAngle0(float JIAODU0);
void Contral_SetAngle1(float JIAODU1);


#endif