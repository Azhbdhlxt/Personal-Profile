#include <REGX52.H>

typedef unsigned char u8;
typedef unsigned int u16;

void delay(u16 i)
{
   while(i--);
}
unsigned char Key()
{
	   unsigned char Keynum=0;
		 if(P0_2==0){delay(2000);while(P0_2==0);delay(2000);Keynum=3;}
		 if(P0_3==0){delay(2000);while(P0_3==0);delay(2000);Keynum=4;}
		 return Keynum;
}