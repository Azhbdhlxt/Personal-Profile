#ifndef __DELAY_H__
#define __DELAY_H__


void Delay1ms(unsigned int x);
void Delay_DS18B20(unsigned int t);

#endif