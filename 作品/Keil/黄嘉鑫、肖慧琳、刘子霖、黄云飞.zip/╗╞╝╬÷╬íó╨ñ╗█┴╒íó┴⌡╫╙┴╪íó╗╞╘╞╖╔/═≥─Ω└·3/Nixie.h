#ifndef __NIXIE_H__
#define __NIXIE_H__

#define uint unsigned int
#define uchar unsigned char 

extern unsigned char alarm[3];
void Display1(unsigned char pos,value);
void Display2(unsigned char pos,value);
void Display3(unsigned char pos,value);
void TimeShow();
void TimeSet();

#endif