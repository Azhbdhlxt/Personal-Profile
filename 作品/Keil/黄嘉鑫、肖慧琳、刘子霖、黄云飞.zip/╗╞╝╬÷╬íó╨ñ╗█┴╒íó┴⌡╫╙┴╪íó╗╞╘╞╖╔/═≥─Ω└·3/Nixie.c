#include <REGX52.H>
#include <intrins.h>
#include "Delay.h"
#include "DS1302.h"
#include "DS18B20.h"
#include "Nixie.h"

sbit k1 = P0^1;
sbit k2 = P0^2;
sbit k3 = P0^3;

static unsigned char wx = 24;//位选
uchar a = 2,b = 0;

void Display1(uchar pos,value)
{
	static uchar temp1;
	if(pos == wx)     // 0 1 2 3 4 5 6 7
	{
		temp1++;
		if(temp1 == 40)
			temp1 = 0;
		if(temp1 < 20) P1 = 15<<4|0x0f;//选中这些位控制亮灭
		else P1 = value << 4|0x0f;
		
		P2 = pos << 4| 0x0f;
		Delay1ms(1);
		P1 = 0xff;
	}
	else
	{
		P1 = value << 4|0x0f;
		P2 = pos << 4| 0x0f;
		Delay1ms(1);
		P1 = 0xff;
	}
	
}
 
void Display2(uchar pos,value)
{
	static uchar temp2;
	if(pos + 8 == wx)  // 10 11 12 13 14 15
	{
		temp2++;
		if(temp2 == 40)
			temp2 = 0;
		if(temp2 < 20) P1 = value | 0xf0;//选中这些位控制亮灭
		else P1 = 15 | 0xf0;
		
		P2 = pos << 4 | 0x0f;
		Delay1ms(1);
		P1 = 0xff;
	}
	else
	{
		P2 = pos << 4 | 0x0f;
		P1 = value | 0xf0;
		Delay1ms(1);
		P1 = 0xff;
	}
	
}
 
void Display3(uchar pos,value)
{
	static uchar temp3;
	if(pos + 16 == wx)  // 17 18 19 20 21 22 23选中这些位控制亮灭
	{
		temp3++;
		if(temp3 == 40)
			temp3 = 0;
		if(temp3 < 20) P2 = pos<<4|15;
		else P2 = pos << 4 | value;
		
		Delay1ms(1);
		P2 = pos << 4 | 0x0f;
	}
	else
	{
		P2 = pos << 4 | value;
		Delay1ms(1);
		P2 = pos << 4 | 0x0f;
	}
	
}
 
 
void TimeShow()
{
	DS1302_ReadTime();
	
	//年月日
	Display1(0,a);
	Display1(1,b);
	Display1(2,Time[0] / 10);
	Display1(3,Time[0] % 10);
	Display1(4,Time[1] / 10);
	Display1(5,Time[1] % 10);
	Display1(6,Time[2] / 10);
	Display1(7,Time[2] % 10);
	
	//星期
	//	Display3(0,Time[6] / 10);
	Display3(1,Time[6] % 10);
	
	//时间
	Display3(2,Time[3] / 10);
	Display3(3,Time[3] % 10);
	Display3(4,Time[4] / 10);
	Display3(5,Time[4] % 10);
	Display3(6,Time[5] / 10);
	Display3(7,Time[5] % 10);
	
	//温度
	Display2(0,temp / 10);
	Display2(1,temp % 10);
	
	//闹钟
	Display2(2,alarm[2] / 10);  
	Display2(3,alarm[2] % 10);
	Display2(4,alarm[1] / 10);
	Display2(5,alarm[1] % 10);
	Display2(6,alarm[0] / 10);
	Display2(7,alarm[0] % 10);
	
}

void TimeSet()
{
	bit flag;
	//设置
	if(!k1 && !flag)
	{
		Delay1ms(10);
		if(!k1)
		{
			flag = 1;
			wx = (wx + 1) % 25;
			if(wx == 8) wx = 10;
			if(wx == 16) wx = 17;
		}
		else if(k1)
		{
			flag = 0;
		}
	}
	
	//调大
	if(!k2 && !flag)
	{
		Delay1ms(10);
		if(!k2)
		{
			flag = 1;
			switch(wx)
			{
				case 0: a += 1;if(a > 9) a = 1; break;
				case 1: b += 1;if(b > 9) b = 0; break;
				case 2: Time[0] = (Time[0]/10 + 1)*10 + Time[0]%10;if(Time[0]>99) Time[0] = 0; DS1302_Write();break;
				case 3: Time[0] += 1;if(Time[0] > 99) Time[0] = 0; DS1302_Write(); break;
				case 4: Time[1] = (Time[1] / 10 + 1) * 10 + Time[1] % 10;if(Time[1]> 12) Time[1] = 1; DS1302_Write();break;
				case 5: Time[1] += 1;if(Time[1] > 12) Time[1] = 1;DS1302_Write();break;
				case 6: Time[2] = (Time[2] / 10 + 1)*10 + Time[2]%10; if(Time[2] > 31) Time[2] = 1; DS1302_Write();break;
				case 7: Time[2] += 1;if(Time[2] > 31) Time[2] = 1;DS1302_Write();break;
					
				case 10: alarm[2] = (alarm[2] / 10 + 1)*10 + alarm[2] % 10; if(alarm[2]>23) alarm[2] = 0; break;
				case 11: alarm[2] += 1;if(alarm[2] > 23) alarm[2] = 0;break;
				case 12: alarm[1] = (alarm[1] / 10 + 1)*10 + alarm[1] % 10; if(alarm[1]>59) alarm[1] = 0;break;
				case 13: alarm[1] += 1;if(alarm[1]>59) alarm[1] = 0;break;
				case 14: alarm[0] = (alarm[0] / 10 + 1)*10 + alarm[0] % 10;if(alarm[0] > 59) alarm[0] = 0;break;
				case 15: alarm[0] += 1; if(alarm[0] > 59) alarm[0] = 0;break;
				
				case 17: Time[6] += 1; if(Time[6] > 7) Time[6] = 1;DS1302_Write();break;//星期
				case 18: Time[3] = (Time[3]/10 + 1) * 10 + Time[3] % 10; if(Time[3]>23) Time[3] = 0;DS1302_Write(); break;
				case 19: Time[3] += 1;if(Time[3] > 23)Time[3] = 0;DS1302_Write();break;
				case 20: Time[4] = (Time[4]/10 + 1) * 10 + Time[4] %10;if(Time[4]>59) Time[4] = 0;DS1302_Write();break;
				case 21: Time[4] += 1;if(Time[4] > 59) Time[4]  = 0;DS1302_Write();break;
				case 22: Time[5] = (Time[5] / 10 + 1) * 10 + Time[5] %10; if(Time[5] > 59) Time[5] = 0; DS1302_Write();break;
				case 23: Time[5] += 1; if(Time[5] > 59) Time[5]  = 0;DS1302_Write();break;
			}
		}
		else if(k2)
		{
			flag = 0;
		}
	}

	//调小
	if(!k3 && !flag)
	{
		Delay1ms(10);
		if(!k3)
		{
			flag = 1;
			switch(wx)
			{
				case 0:a-=1;if(a < 1)a = 1;break;
				case 1:b-=1;if(b < 0)b = 9;break;
				case 2:if(Time[0] < 10) Time[0]=109; Time[0]-=10; DS1302_Write(); break;
				case 3:if(Time[0] < 0) Time[0]=0; Time[0]-=1; DS1302_Write(); break;
				case 4:if(Time[1] < 10) Time[1]=22; Time[1]-=10; DS1302_Write(); break;
				case 5:if(Time[1] < 0) Time[1]=2; Time[1]-=1; DS1302_Write(); break;
				case 6:if(Time[2] < 10) Time[2]=41;Time[2]-=10; DS1302_Write();break;
				case 7:if(Time[2] < 0) Time[2]=4;Time[2]-=1; DS1302_Write(); break;
				
				case 10:if(alarm[2] < 10) alarm[2]=33;alarm[2]-=10; break;
				case 11:if(alarm[2] < 0) alarm[2]=24; alarm[2]-=1; break;
				case 12:if(alarm[1]< 10) alarm[1]=69; alarm[1]-=10; break;
				case 13:if(alarm[1] <0) alarm[1]=60;alarm[1]-=1;break;
				case 14:if(alarm[0] < 10) alarm[0]=69; alarm[0]-=10;break;
				case 15:if(alarm[0]< 0) alarm[0]=60; alarm[0]-=1;	break;
				
				case 17:if(Time[6] <= 1) Time[6]=8;Time[6]-=1;DS1302_Write();break;//星期			
				case 18:if(Time[3] < 10) Time[3]=33;Time[3]-=10;DS1302_Write();break;  
				case 19:if(Time[3] < 0) Time[3]=24;Time[3]-=1;DS1302_Write();break;
				case 20:if(Time[4]< 10) Time[4]=69; Time[4]-=10;DS1302_Write();break;
				case 21:if(Time[4] < 0) Time[4]=60;Time[4]-=1;DS1302_Write();break;
				case 22:if(Time[5] < 10) Time[5]=69;Time[5]-=10;DS1302_Write();break;
				case 23:if(Time[5]< 0) Time[5]=60;Time[5]-=1;DS1302_Write();break;
			}
		}
		else if(k3)
		{
			flag = 0;
		}
	}
}
