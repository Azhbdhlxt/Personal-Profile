#ifndef __DS18B20_H__
#define __DS18B20_H__

#define uint unsigned int
#define uchar unsigned char 
sbit DQ = P0^7;
extern unsigned int temp;
bit Init_DS18B20();
unsigned char Read_DS18B20();
void Write_DS18B20(unsigned char dat);
void Get_Temper();

#endif