#include <intrins.h>
#include <regx52.h>

#define uint unsigned int
#define uchar unsigned char
#define  SECOND 0X80
#define  MINUTE 0X82
#define  HOUR 0X84
#define  DATE 0X86
#define  MONTH 0X88
#define  DAY 0X8A
#define  YEAR 0X8C
#define  WP 0X8E

sbit SPEA = P0 ^ 6;
sbit DS = P0 ^ 7;
uint temp;
sbit SCK = P3 ^ 4;
sbit IO = P3 ^ 3;
sbit CE = P3 ^ 2;
sbit SET = P0 ^ 1;
sbit SSET = P0 ^ 2;
sbit ADD = P0 ^ 3;
uchar Time[7];
uchar STime[7];
uchar code read_addr[7] = {0x81, 0x83, 0x85, 0x87, 0x89, 0x8b, 0x8d};
uchar Ttime[3];
uchar year[2] = {2, 0};
uchar set = 0;
uchar sset = 0;
uchar sw = 0;
uint DATA[9];
bit f;  

void delay1ms(uint i)
{
	uchar j;

	while(-- i)
	{
		for(j = 0;j < 125;++ j);
	}
}

void disp1(uchar i, j)
{
	-- j;
	P1 = i << 4 | 0x0f;
	P2 = j << 4 | 0x0f;
	delay1ms(2);
	P1 = 0xff;
}

void disp2(uchar i, j)
{
	-- j;
	P1 = i | 0xf0;
	P2 = j << 4 | 0x0f;
	delay1ms(3);
	P1 = 0xff;
}

void disp3(uchar i, j)
{
	++ j;
	P2 = j << 4 | i;
	delay1ms(3);
	P2 = j << 4 | 0x0f;
}

void dsreset()
{
	uint i;
	DS = 0;
	i = 103;
	while(i) i --;
	DS = 1;
	i = 4;
	while(i) i --;
}

bit tmpreadbit()
{
	uint i;
	bit dat;
	DS = 0;
	i ++;
	DS = 1;
	i ++;
	i ++;
	dat = DS;
	i = 8;
	while(i) i --;
	return dat;
}

uchar tmpread(void)
{
	uchar i, j, dat;
	for(i = 1;i <= 8;++ i)
	{
		j = tmpreadbit();
		dat = (j << 7) | (dat >> 1);
	}

	return (dat);
}

void tmpwritebyte(uchar dat)
{
	uint i;
	uchar j;
	bit testb;
	for(j = 1;j <= 8;j ++)
	{
		testb = dat & 0x01;
		dat = dat >> 1;
		if(testb)
		{
			DS = 0;
			i ++;
			i ++;
			DS = 1;
			i = 8;
			while(i) i --;
		}
		else
		{
			DS = 0;
			i = 8;
			while(i) i --;
			DS = 1;
			i ++;
			i ++;
		}
	}
}

void tmpchange()
{
	dsreset();
	delay1ms(2);
	tmpwritebyte(0xcc);
	tmpwritebyte(0x44);
}

uint tmp()
{
	float tt;
	uchar a, b;
	dsreset();
	delay1ms(2);
	tmpwritebyte(0xcc);
	tmpwritebyte(0xbe);
	a = tmpread();
	b = tmpread();
	temp = b;
	temp <<= 8;
	temp = temp | a;
	tt = temp * 0.0625;
	temp = tt * 10 + 0.5;
	return temp;
}

void displayt(uint temp)
{
	uchar A1, A2;
	A2 = temp / 10 % 10;
	A1 = temp / 100 % 10;

	disp2(A1, 1);
	disp2(A2, 2);
}

void d_init()
{
	CE = 0;
	SCK = 0;
}

void DW(uchar tmp) 
{
	uchar i;
	for(i=0;i<8;i++)     	
	{ 
		SCK=0;
		IO=tmp&0x01;
		tmp>>=1; 
		SCK=1;
	}
} 
void DWB( uchar address, uchar dat )     
{
 	CE=0;	_nop_();
 	SCK=0;	_nop_();
 	CE=1; 	_nop_();  
 	DW(address);	
 	DW(dat);		
 	CE=0; 
}

uchar DRB( uchar address )
{
 	uchar i,tmp=0x00;
 	CE=0;	_nop_();
 	SCK=0;	_nop_();
 	CE=1;	_nop_();
 	DW(address);
 	for (i=0;i<8;i++) 	
 	{		
		SCK=0;
		tmp>>=1;	
 		if(IO)
 		tmp|=0x80;	
 		SCK=1;
	} 
 	CE=0;	_nop_();
 	SCK=0;	_nop_();
	SCK=1;	_nop_();
	IO=0;	_nop_();
	IO=1;	_nop_();
	return (tmp);			
}

void SetTime()
{
		DWB(WP,0x00);
		DWB(YEAR, STime[0]/10*16+STime[0]%10);
		DWB(MONTH, STime[1]/10*16+STime[1]%10);
		DWB(DATE, STime[2]/10*16+STime[2]%10);
		DWB(HOUR, STime[3]/10*16+STime[3]%10);
		DWB(MINUTE, STime[4]/10*16+STime[4]%10);
		DWB(SECOND, STime[5]/10*16+STime[5]%10);
		DWB(DAY, STime[6]/10*16+STime[6]%10);
		DWB(WP,0x80);
}

void read()
{
	uchar i;
	for(i=0;i<7;i++)
	{
		Time[i] = DRB(read_addr[i]);
	}
	
}

void dispd()
{
	disp1(year[0], 1);
	disp1(year[1], 2);
	disp1(Time[6] / 16, 3);
	disp1(Time[6] % 16, 4);
	disp1(Time[4] / 16, 5);
	disp1(Time[4] % 16, 6);
	disp1(Time[3] / 16, 7);
	disp1(Time[3] % 16, 8);
	disp3(Time[2] / 16, 1);
	disp3(Time[2] % 16, 2);
	disp3(Time[1] / 16, 3);
	disp3(Time[1] % 16, 4);
	disp3(Time[0] / 16, 5);
	disp3(Time[0] % 16, 6);
}

void dispt()
{
	disp2(Ttime[0] / 10, 3);
	disp2(Ttime[0] % 10, 4);
	disp2(Ttime[1] / 10, 5);
	disp2(Ttime[1] % 10, 6);
	disp2(Ttime[2] / 10, 7);
	disp2(Ttime[2] % 10, 8);
}

void disps()
{
	if(sw != 0 || f)
	{
		disp1(DATA[0] / 1000 % 10, 1);
		disp1(DATA[0] / 100 % 10, 2);
		disp1(DATA[0] / 10 % 10, 3);
		disp1(DATA[0] % 10, 4);
	}
	if(sw != 1 || f)
	{
		disp1(DATA[1] / 10, 5);
		disp1(DATA[1] % 10, 6);
	}
	if(sw != 2 || f)
	{
		disp1(DATA[2] / 10, 7);
		disp1(DATA[2] % 10, 8);
	}
	if(sw != 3 || f)
	{
		disp2(DATA[3] / 10, 3);
		disp2(DATA[3] % 10, 4);
	}
	if(sw != 4 || f)
	{
		disp2(DATA[4] / 10, 5);
		disp2(DATA[4] % 10, 6);
	}
	if(sw != 5 || f)
	{
		disp2(DATA[5] / 10, 7);
		disp2(DATA[5] % 10, 8);
	}
	if(sw != 6 || f)
	{
		disp3(DATA[6] / 10, 1);
		disp3(DATA[6] % 10, 2);
	}
	if(sw != 7 || f)
	{
		disp3(DATA[7] / 10, 3);
		disp3(DATA[7] % 10, 4);
	}
	if(sw != 8 || f)
	{
		disp3(DATA[8] / 10, 5);
		disp3(DATA[8] % 10, 6);
	}
}

void timeinit0()
{
	TMOD = 0x01;
	TH0 = (65535 - 500)/256;
	TL0 = (65535 - 500)%256;
	ET0 = 1;
	EA = 1;
	TR0 = 1;
}
main()
{
	P1 = 0xff;
	d_init();
	timeinit0();
	EA = 0;
	SPEA = 0;
	while(1)
	{
		if(SET == 0)
		{
			while(SET == 0);
			if(set == 0)
			{
				set = 1;
				sw = 0;

				DATA[0] = year[0] * 1000 + Time[6]/16*10 + Time[6]%16;
				DATA[1] = Time[4]/16*10 + Time[4]%16;
				DATA[2] = Time[3]/16*10 + Time[3]%16;
				DATA[3] = Ttime[0];
				DATA[4] = Ttime[1];
				DATA[5] = Ttime[1];
				DATA[6] = Time[2]/16*10 + Time[2]%16;
				DATA[7] = Time[1]/16*10 + Time[1]%16;
				DATA[8] = Time[0]/16*10 + Time[0]%16;
				EA = 1;

			}
			else
			{
				set = 0;
				EA = 0;
				year[0] = (uchar)(DATA[0] / 1000);
				year[1] = (uchar)(DATA[0] / 100 % 10);
				STime[0] = (uchar)(DATA[0] % 100);
				STime[1] = (uchar)(DATA[1]);
				STime[2] = (uchar)(DATA[2]);
				Ttime[0] = (uchar)(DATA[3]);
				Ttime[1] = (uchar)(DATA[4]);
				Ttime[2] = (uchar)(DATA[5]);
				STime[3] = (uchar)(DATA[6]);
				STime[4] = (uchar)(DATA[7]);
				STime[5] = (uchar)(DATA[8]);
				SetTime();
			}
		}

		if(SSET == 0)
		{
			while(SSET == 0);
			sw = (sw + 1) % 9;
		}
		if(ADD == 0)
		{
			while(ADD == 0);
			if(sw == 1)
			{
				DATA[1] ++;
				if(DATA[1] == 13) DATA[1] = 1;
			} 
			else if(sw == 2)
			{
				DATA[2] ++;
				if(DATA[2] == 32) DATA[2] = 1;
			}
			else if(sw == 3)
			{
				DATA[3] ++;
				if(DATA[3] == 25) DATA[3] = 1;
			}
			else if(sw == 4)
			{
				DATA[4] ++;
				if(DATA[4] == 61) DATA[4] = 1;
			}
			else if(sw == 5)
			{
				DATA[5] ++;
				if(DATA[5] == 61) DATA[5] = 1;
			}
			else if(sw == 6)
			{
				DATA[6] ++;
				if(DATA[6] == 25) DATA[6] = 1;
			}
			else if(sw == 7)
			{
				DATA[7] ++;
				if(DATA[7] == 61) DATA[7] = 1;
			}
			else if(sw == 8)
			{
				DATA[8] ++;
				if(DATA[8] == 61) DATA[8] = 1;
			}
			else DATA[0] ++;
		}
		tmpchange();
		displayt(tmp());
		if(set == 0)
		{
			read();
			dispd();
			dispt();
		}
		else
		{
			disps(); 
		}
		if(Time[2]/16*10 + Time[2]%16 == Ttime[0] && Time[1]/16*10 + Time[1]%16 == Ttime[1]) SPEA = 1;
		else SPEA = 0;
	}	
}

void inter() interrupt 1
{
	TH0 = (65535 - 500)/256;
	TL0 = (65535 - 500)%256;
	f = !f;
	 
}