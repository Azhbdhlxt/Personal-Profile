#include <REGX52.H>
#include "Delay.h"
#include "DS1302.h"
#define uint unsigned int
#define uchar unsigned char

sbit DS1302_SCLK=P3^4;
sbit DS1302_IO=P3^3;
sbit DS1302_CE=P3^2;

//#define DS1302_SECOND  0x80
//#define DS1302_MINUTE  0x82
//#define DS1302_HOUR    0x84
//#define DS1302_DATE    0x86
//#define DS1302_MONTH   0x88
//#define DS1302_DAY     0x8A
//#define DS1302_YEAR    0x8C
//#define DS1302_WP      0x8E
unsigned char WriteRFlag[7] = {0x8c,0x88,0x86,0x84,0x82,0x80,0x8A};
char Time[7]={23,12,27,8,59,55,6};//年、月、日、时、分、秒、星期

//初始化
void DS1302_Init()
{
	DS1302_CE=0;
	DS1302_SCLK=0;
}

//写数据
void DS1302_WriteByte(unsigned char dat)
{
	unsigned char i;
	DS1302_SCLK = 0;
	for(i = 0; i < 8; i++)
	{
		if(dat & 0x01)
		{
			DS1302_IO = 1;
		}
		else
		{
			DS1302_IO = 0;
		}
		DS1302_SCLK = 1;
		DS1302_SCLK = 0;
		dat = dat >> 1;
	}
}

void DS1302_WriteSingleByte(unsigned char com, dat)
{
	unsigned char i;
	DS1302_Init();
	DS1302_CE=1;
	com = com & 0xfe;
	DS1302_WriteByte(com);
	i = (dat/10<<4)|(dat%10);
	DS1302_WriteByte(i);
	DS1302_CE=0;
  DS1302_IO=0;
}


void DS1302_Write()
{
	unsigned char i;
	DS1302_WriteSingleByte(0x8e,0x00);//写保护
	for(i = 0; i < 7; i++)
		DS1302_WriteSingleByte(WriteRFlag[i],Time[i]);
	DS1302_WriteSingleByte(0x8e,0x80);
}

//读数据
unsigned char DS1302_ReadByte()
{
	unsigned char i,dat=0;
	for(i=0;i<8;i++)
	{
		dat=dat>>1;
		if(DS1302_IO)
		{
			dat|=0x80;
		}
		else
		{
			dat&=0x7f;
		}
		DS1302_SCLK=1;
		DS1302_SCLK=0;
	}
	return dat;
}

unsigned char DS1302_ReadSingleByte(unsigned char com)
{
	unsigned char temp,dat1,dat2;
	DS1302_Init();
	DS1302_CE=1;
	com = com | 0x01;
	DS1302_WriteByte(com);
	temp=DS1302_ReadByte();
	dat1=temp/16;
	dat2=temp%16;
	temp=dat1*10+dat2;
	DS1302_CE=0;
	DS1302_IO=0;
	return temp;
}


void DS1302_ReadTime()
{
	unsigned char i;
	for(i=0;i<7;i++)
	{
		Time[i] = DS1302_ReadSingleByte(WriteRFlag[i]);
	}
}