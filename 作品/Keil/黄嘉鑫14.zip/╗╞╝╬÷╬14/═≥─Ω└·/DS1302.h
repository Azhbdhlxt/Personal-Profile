#ifndef __DS1302_H__
#define __DS1302_H__

extern char Time[7];
void DS1302_Init();
void DS1302_WriteByte(unsigned char dat);
void DS1302_WriteSingleByte(unsigned char cmd, unsigned char dat);
void DS1302_Write();
unsigned char DS1302_ReadByte();
unsigned char DS1302_ReadSingleByte(unsigned char com);
void DS1302_ReadTime();

#endif