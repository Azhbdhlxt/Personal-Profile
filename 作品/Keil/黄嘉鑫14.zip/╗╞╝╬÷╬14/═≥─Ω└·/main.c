#include <REGX52.H>
#include <INTRINS.H>
#include "Nixie.h"
#include "DS1302.h"
#include "Delay.h"
#include "DS18B20.h"
#define uint unsigned int
#define uchar unsigned char 

sbit speaker = P0^6;
uchar alarm[3] = {0,0,0};

void main()
{
	unsigned char i;
//	DS1302_Write();//记忆初始年月日时分秒值//做测试用
	while(1)
	{
		speaker = 1;
		Get_Temper();
		DS1302_ReadTime();
		if(alarm[2] == Time[3] && alarm[1] == Time[4] && alarm[0] == Time[5])
		{
			for(i = 0; i < 200; i++)
			{
				TimeSet();
				TimeShow();
				Delay1ms(1);
				DS1302_ReadTime();
				speaker=!speaker;
			}
		}
		TimeSet();
		for(i = 0; i < 10; i++)
		{
			TimeShow();
		}
	}
}
