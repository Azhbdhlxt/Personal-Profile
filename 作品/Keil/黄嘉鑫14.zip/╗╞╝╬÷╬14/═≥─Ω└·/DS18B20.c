#include <REGX52.H>
#include <INTRINS.H>
#include "Delay.h"
#include "DS18B20.h" 
uint temp;

 
//初始化
bit Init_DS18B20()
{
	bit dat = 0;
	DQ = 1;
	_nop_();
	DQ = 0;
	Delay_DS18B20(75); 
	DQ = 1;
	Delay_DS18B20(4); 
	dat = DQ;    
	Delay_DS18B20(10);
  	DQ=1;
	nop_();
	return dat;
}
 
//写入一个字节
void Write_DS18B20(unsigned char dat)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		nop_();
		DQ = dat&0x01;
		Delay_DS18B20(4);
		DQ = 1;
		nop_();
		dat >>= 1;
	}
}
 
//读取一个字节
unsigned char Read_DS18B20()
{
	uchar i, j, dat;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		_nop_();//产生读时序
		DQ = 1;
		_nop_();//释放总线
		j = DQ;
		Delay_DS18B20(4);
		DQ = 1;
		_nop_();
		dat = (j<<7)|(dat>>1);	
	}
	return dat;
}

//获取温度
void Get_Temper()
{
	uchar lsb,hsb;
	Init_DS18B20();
	Write_DS18B20(0xcc);//发出跳过检测ROM的指令
	Write_DS18B20(0x44);//发出转换开始指令
	Delay_DS18B20(200);
	Init_DS18B20();
	Write_DS18B20(0xcc);
	Write_DS18B20(0xbe);
	lsb = Read_DS18B20();//低八位
	hsb = Read_DS18B20();//高八位
	temp = (hsb << 8) | lsb;
	if((temp & 0xf8000) == 0x0000)
		temp = temp >> 4;
}