#include <REGX52.H>
#include "Delay.h"

void Delay1ms(unsigned int x)
{
	unsigned int i,j;
	for(i = 0; i < x; i++)
		for(j = 0; j <123; j++);
}

//DS18B20单总线延时函数
void Delay_DS18B20(unsigned int t)
{
	while(t--);
}