	#include<reg52.h>
	#include<intrins.h>
	#include "ds18b20.h"
	sbit P10 = P1^0;
	sbit P11 = P1^1;
	sbit P12 = P1^2;
	sbit P13 = P1^3;
	sbit P14 = P1^4;
	sbit P15 = P1^5;
	sbit P16 = P1^6;
	
	sbit sh = P2^0;
	sbit ds = P2^1;
	sbit st = P2^2;
	sbit ds1302_sclk = P2^5;
	sbit ds1302_io = P2^6;
	sbit ds1302_ce = P2^4;
	
	sbit key1 = P3^5;
	sbit key2 = P3^6;
	sbit key3 = P3^7;
	sbit key4 = P3^4;
	
	sbit buz = P2^7; //������
	//�Ĵ���д���ַ/ָ���
	#define DS1302_SECOND		0x80
	#define DS1302_MINUTE		0x82
	#define DS1302_HOUR			0x84
	#define DS1302_DATE			0x86
	#define DS1302_MONTH		0x88
	#define DS1302_DAY			0x8A
	#define DS1302_YEAR			0x8C
	#define DS1302_WP			0x8E
	
	//ʱ�����飬����0~6�ֱ�Ϊ�ꡢ�¡��ա�ʱ���֡��롢����,��������޸�
	unsigned char DS1302_Time[]={23,12,26,10,20,05,2};
	unsigned int a=0,b=0,c=0,d=0,e=0,f=0,g=0,h=0;z=0; //������˸
	unsigned int a1=10,b1=10,c1=10,d1=10,e1=10,f1=10,g1=10,h1=10;z1=10; //������˸
	
	unsigned char tim1=0,tim2=0,tim3=0; //tim1 - Сʱ ��tim2 - ���ӣ� tim3 - ��
	
	unsigned char count=0;
	bit dsflag=1; //�Ƿ���ds1302��ȡ
	bit timflag=0; //�Ƿ�����ʱ�������ǵ�ȷ�ϰ�ť
	bit tflag;
	unsigned code duan[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x00,0x00}; 
	
	unsigned code status[] = {0x78,0x79,0x7a,0x7b,0x7c,0x7d,0x7e,0x77,0x07,0x0f,0x17,0x1f,0x27,0x2f,0x37,0x3f,0x47,0x4f,0x57,0x5f,0x67,0x6f}; 
	// 
	void delay(unsigned char x){
	unsigned char i,j;
	while(x--){
		i = 5;
		j = 138;
		do
		{
			while (--j);
		} while (--i);	
	}
	}
	
	void delay1us(unsigned char x){
	while(x--);
	
	}
	/*��ʾģ��*/
	void write_595(unsigned char dat){
	unsigned char i;
	sh = 0;
	st = 0;
	for(i=0;i<8;i++){
		ds = dat&0x80;	 //1000 0000 
		
		sh = 1;
		sh = 0;
		dat=dat<<1;
	}
		st =1;
		st =0;
		//��ʱ��Ҫ����
		delay1us(2000);
		//ȫд0
	    sh = 0;
		st = 0;
		for(i=0;i<8;i++){
			ds = 0;	 //0000 0000 
			
			sh = 1;
			sh = 0;
		}
			st =1;
			st =0;
	}
	void show_year(unsigned int year){
	
	
	P1 = status[0];
	write_595(duan[2]);		  //2023 / 1000
	
	P1= status[1]; //0x79
	write_595(duan[0]);			// 2023/100
	
	P1 = status[2];//0x7a
	write_595(duan[year/10]);
	
	P1 = status[3];
	write_595(duan[year%10]);
	}
	void show_yearnone(){
	P1 = status[0];
	write_595(duan[11]);		  //2023 / 1000
	P1 = status[1];
	write_595(duan[11]);			// 2023/100
	P1 = status[2];
	write_595(duan[11]);
	P1 = status[3];
	write_595(duan[11]);
	}
	void show_month(unsigned int month){
	P1 = status[4];
	write_595(duan[month/10]);		  //2023 / 1000
	P1 = status[5];
	write_595(duan[month%10]);			// 2023/100
	
	}
	void show_monthnone(){
	P1 = status[4];
	write_595(0x00);		  //2023 / 1000
	P1 = status[5];
	write_595(0x00);			// 2023/100
	}
	void show_day(unsigned int day){
	P1 = status[6];
	write_595(duan[day/10]);
	P1 = status[7];
	write_595(duan[(day%10)]);	 
	
	}
	void show_daynone(unsigned int day){
	P1 = status[6];
	write_595(0x00);
	P1 = status[7];
	write_595(0x00);	 
	
	}
	void show_temvalue(){
	  unsigned int temp;  
	  	temp=Rtem();  //��ȡ�¶�ֵ 
		P1 = status[8];
		write_595(duan[temp/10]);
		P1 = status[9];
		write_595(duan[temp%10]);
	}
	void show_none(){
	 	P1 = status[8];
		write_595(0x00);
		P1 = status[8];
		write_595(0x00);
	}
	void show_tim1(){
	P1 = status[10];
	write_595(duan[tim1/10]);
	P1 = status[11];
	write_595(duan[(tim1%10)]);	 
	
	} 
	void show_tim1none(){
	P1 = status[10];
	write_595(0x00);
	P1 = status[11];
	write_595(0x00);	 
	
	}
	void show_tim2(){
	P1 = status[12];
	write_595(duan[tim2/10]);
	P1 = status[13];
	write_595(duan[(tim2%10)]);	 
	
	}
	void show_tim2none(){
	P1 = status[12];
	write_595(0x00);
	P1 = status[13];
	write_595(0x00); 
	}
	void show_tim3(){
	P1 = status[14];
	write_595(duan[tim3/10]);
	P1 = status[15];
	write_595(duan[(tim3%10)]);	 
	
	}
	void show_tim3none(){
	P1 = status[14];
	write_595(0x00);
	P1 = status[15];
	write_595(0x00);	 
	
	}
	void show_hour(unsigned int hour){
	P1 = status[16];
	write_595(duan[hour/10]);		  //2023 / 1000
	P1 = status[17];
	write_595(duan[hour%10]);			// 2023/100	
	}
	void show_hournone(unsigned int hour){
	P1 = status[16];
	write_595(duan[11]);		  //2023 / 1000
	P1 = status[17];
	write_595(duan[11]);			// 2023/100	
	}
	void show_min(unsigned int min){
	P1 = status[18];
	write_595(duan[min/10]);
	P1 = status[19];
	write_595(duan[min%10]);
	}
	void show_minnone(unsigned int min){
	P1 = status[18];
	write_595(duan[11]);
	P1 = status[19];
	write_595(duan[11]);
	}
	void show_sec(unsigned int sec){
	P1 = status[20];
	write_595(duan[sec/10]);
	P1 = status[21];
	write_595(duan[sec%10]); 
	}
	void show_secnone(unsigned int sec){
	P1 = status[20];
	write_595(0x00);
	P1 = status[21];
	write_595(0x00); 
	}
	
	/*ds1302ʱ��ģ��*/
	void init_ds1302(){
	ds1302_ce = 0;
	ds1302_sclk = 0;
	}
	void  write_ds1302(unsigned char com,unsigned char dat){
	unsigned char i;
	ds1302_ce = 1;
	for(i=0;i<8;i++){
		ds1302_io = com&(0x01<<i); //���λ��ʼ
		ds1302_sclk = 1;   //������0�������߾��ǿ�ʼ����
		ds1302_sclk = 0;   //�ص�ԭ���ĵ�ַ
	}
	for(i=0;i<8;i++){
		ds1302_io = dat&(0x01<<i);
		ds1302_sclk = 1;
		ds1302_sclk = 0;
	}
	ds1302_ce = 0;//����д
	
	}
	unsigned char read_ds1302(unsigned char com){
	 unsigned char dat=0;  //ע������һ��Ҫ����ֵ
	 unsigned char i;
	 com |= 0x01;  	//ת��Ϊ��ָ���ֵֹ����
	 ds1302_ce = 1;	//��ʼ��
	 for(i=0;i<8;i++){
	 	ds1302_io = com&(0x01<<i);
		ds1302_sclk = 0;
		ds1302_sclk = 1;
	 }
	 	delay1us(5);
	 for(i=0;i<8;i++){	
		ds1302_sclk = 1;
		ds1302_sclk = 0;
		if(ds1302_io){
			dat |= (0x01<<i);
		}
	 }
	 ds1302_ce = 0;	//������ds1302_ce = 0;	//������
	 ds1302_io = 0;//����Ҫ��ֹ����io����
	 ds1302_sclk=0;		//---------------
	 return dat;
	}
	//����ʱ��
	void ds1302_setTime(){
	write_ds1302(DS1302_WP,0x00);			  //��д����
	write_ds1302(DS1302_YEAR,DS1302_Time[0]/10*16+DS1302_Time[0]%10); //��Ϊds1302������BCD�룬��������Ҫת��
	write_ds1302(DS1302_MONTH,DS1302_Time[1]/10*16+DS1302_Time[1]%10);
	write_ds1302(DS1302_DATE,DS1302_Time[2]/10*16+DS1302_Time[2]%10);
	write_ds1302(DS1302_HOUR,DS1302_Time[3]/10*16+DS1302_Time[3]%10);
	write_ds1302(DS1302_MINUTE,DS1302_Time[4]/10*16+DS1302_Time[4]%10);
	write_ds1302(DS1302_SECOND,DS1302_Time[5]/10*16+DS1302_Time[5]%10);
	write_ds1302(DS1302_DAY,DS1302_Time[6]/10*16+DS1302_Time[6]%10);
	write_ds1302(DS1302_WP,0x80);
	}
	//��ʱ�䣬ʱ�����ݱ�����   DS1302_Time  ��
	void DS1302_ReadTime(void)
	{
	unsigned char Temp;
	Temp=read_ds1302(DS1302_YEAR);
	DS1302_Time[0]=Temp/16*10+Temp%16;//BCD��תʮ���ƺ��ȡ
	Temp=read_ds1302(DS1302_MONTH);
	DS1302_Time[1]=Temp/16*10+Temp%16;
	Temp=read_ds1302(DS1302_DATE);
	DS1302_Time[2]=Temp/16*10+Temp%16;
	Temp=read_ds1302(DS1302_HOUR);
	DS1302_Time[3]=Temp/16*10+Temp%16;
	Temp=read_ds1302(DS1302_MINUTE);
	DS1302_Time[4]=Temp/16*10+Temp%16;
	Temp=read_ds1302(DS1302_SECOND);
	DS1302_Time[5]=Temp/16*10+Temp%16;
	Temp=read_ds1302(DS1302_DAY);
	DS1302_Time[6]=Temp/16*10+Temp%16;
	}
	void showAll(){
		if(dsflag)	        
		DS1302_ReadTime();//��ʱ��
		a++;b++;c++;d++;e++;f++;g++;z++;h++;
		if(a<=a1){
			show_year(DS1302_Time[0]);	
		}else{
			 show_yearnone();
		}
		if(b<=b1){
			show_month(DS1302_Time[1]);	
		}else{
			 show_monthnone();
		}	
		if(c<=c1){
			show_day(DS1302_Time[2]);	
		}else{
			 show_daynone();
		}
		if(d<=d1){  
		   show_tim1();
		}else{
		   show_tim1none();
		}
		if(e<=e1){  
		   show_tim2();
		}else{
		   show_tim2none();
		}
		if(f<=f1){  
		   show_tim3();
		}else{
		   show_tim3none();
		}
		show_temvalue();
		if(g<=g1){  
		   show_hour(DS1302_Time[3]);
		}else{
		   show_hournone();
		}
		if(h<=h1){  
		  	show_min(DS1302_Time[4]);
		}else{
		   	show_minnone();
		}
		if(z<=z1){  
		  	show_sec(DS1302_Time[5]);
		}else{
		   	show_secnone();
		}														
		if(a==10){
			a=0;  }
		if(b==10){
			b=0;  }
		if(c==10){
			c=0;  }
		if(d==10){
			d=0;  }
		if(e==10){
			e=0;  }
		if(f==10){
			f=0;  }
		if(g==10){
			g=0;  }
		if(h==10){
			h=0;  }
		if(z==10){
			z=0;}
	}
	unsigned int key(){
	  unsigned int flag=0,flag1=0,flag2=0,flag3=0;
	  unsigned int ret=0;
	  if(!key1&&!flag){
	  	delay(40);
		if(!key1){
			flag = 1;
			ret=1;
		}
	  }else if(key1){
	  	flag = 0;
	  }
	  if(!key2&&!flag1){
	  	delay(40);
		if(!key2){
			flag1 = 1;
			ret=2;
		}
	  }else if(key2){
	  	flag1 = 0;
	  }
	  if(!key3&&!flag2){
	  	delay(40);
		if(!key3){
			flag2 = 1;
			ret=3;
		}
	  }else if(key3){
	  	flag2 = 0;
	  }
	  if(!key4&&!flag3){
	  	delay(40);
		if(!key4){
			flag3 = 1;
			ret=4;
		}
	  }else if(key4){
	  	flag3 = 0;
	  }
	  return ret;
	}
	void butAck(){
	unsigned int k,b2=0,temp;
	static int i=0;
	k=key();
	if(k==1){		  //ѡ��,ע��Ҫ��ͣDS1302��ȡ
		 i++;
		 dsflag = 0;
		 TR0 = 0; //�Ѷ�ʱ�ص�����ͣ��ʱ
		 tim1=0; tim2=0; tim3=0;   //�³�ͻ
		 timflag=0;  //�رն�ʱ��
	}
	if(k==2){	//������
		if(i==1){
			DS1302_Time[i-1]++; 		
		}
		if(i==2){ //�����·�
			temp = DS1302_Time[i-1];
			b2=(temp)%12+1;
			DS1302_Time[i-1] = b2;
		}
		if(i==3){ //������
			temp = DS1302_Time[i-1];
			b2=(temp+1)%32;
			DS1302_Time[i-1] = b2;
		}
		if(i==4){ //��ʱСʱ
			tim1 +=1;
		}
		if(i==5){ //��ʱ����
			tim2 +=1;
			tim2 %= 60;
		}
		if(i==6){ //��ʱ��
			tim3 +=1;
			tim3 %= 60;
		}
		if(i==7){ //��ʱ
			temp = DS1302_Time[3];
			b2=(temp)%24+1;
			DS1302_Time[3] = b2;
		}
		if(i==8){ //�ӷ���
			temp = DS1302_Time[4];
			b2=(temp+1)%60;
			DS1302_Time[4] = b2;
		}
		if(i==9){ //�ӷ���
			temp = DS1302_Time[5];
			b2=(temp+1)%60;
			DS1302_Time[5] = b2;
		}
	}
	if(k==3){	 //����
		if(i==1){
			DS1302_Time[i-1]--; 		
		}
		if(i==2){ //�����·�
			temp = DS1302_Time[i-1];
			b2=temp-1;
			if(b2==0)  b2 = 12;
			DS1302_Time[i-1] = b2;
		}
		if(i==3){ //������
			temp = DS1302_Time[i-1];
			b2=temp-1;
			if(b2==0)  b2 = 31;
			DS1302_Time[i-1] = b2;
		}
		if(i==4){ //��ʱСʱ
			tim1 -=1;
			if(tim1<0) tim1=0;
		}
		if(i==5){ //��ʱ����
			tim2 -=1;
			if(tim2<0) tim2=60;
		}
		if(i==6){ //��ʱ��
			tim3 -=1;
			if(tim3<0) tim3=60;
		}
		if(i==7){ //Сʱ
			temp = DS1302_Time[3];
			b2=temp-1;
			if(b2==0)  b2 = 24;
			DS1302_Time[3] = b2;
		}
		if(i==8){ //����
			temp = DS1302_Time[4];
			b2=temp-1;
			if(b2==0)  b2 = 60;
			DS1302_Time[4] = b2;
		}
		if(i==8){ //��
			temp = DS1302_Time[5];
			b2=temp-1;
			if(b2==0)  b2 = 60;
			DS1302_Time[5] = b2;
		}
	}
	 if(k==4){ //ȷ��
	 	ds1302_setTime();//����ʱ�䣬�ر���˸
		a1=10;
		b1=10;
		c1=10;
		d1=10;
		e1=10;
		f1=10;
		g1=10;
		h1=10;
		z1=10;
		i=0;
		dsflag = 1; //���¿�ʼ��ȡds1302�¶�
	 	timflag=1;  //������ʱ��
	 }
	 		if(i==1){
				a1=5;
			}
			if(i==2){
				a1=10;
				b1=5;
			}
			if(i==3){
				a1=10;
				b1=10;
				c1=5;
			}
			if(i==4){ //��ʱСʱ��˸
				a1=10;
				b1=10;
				c1=10;
				d1=5;
			
			}
			if(i==5){ //��ʱСʱ��˸
				a1=10;
				b1=10;
				c1=10;
				d1=10;
				e1=5;
			}
			if(i==6){ //��ʱСʱ��˸
				a1=10;
				b1=10;
				c1=10;
				d1=10;
				e1=10;
				f1=5;
			}
			if(i==7){ //Сʱ��˸
				a1=10;
				b1=10;
				c1=10;
				d1=10;
				e1=10;
				f1=10;
				g1=5;
			}
			if(i==8){ //������˸
				a1=10;
				b1=10;
				c1=10;
				d1=10;
				e1=10;
				f1=10;
				g1=10;
				h1=5;
			}
			if(i==9){ //������˸
				a1=10;
				b1=10;
				c1=10;
				d1=10;
				e1=10;
				f1=10;
				g1=10;
				h1=10;
				z1=5;
			}
			if(i>9){
				i=1;
				z1=10;	
			}
	}
	/*��ʱ��ģ�飬ʹ�ö�ʱ��0����ʱ1ms*/
	void inittimer0(){
	 TMOD &= 0xF0;//��ʽ1
	 TH0 = 0xD1 ;
	 TL0 = 0x20;
	 EA = 1;
	 ET0 = 1;
	 TR0 = 0; //������Ҫ������ʱʱ���ã��رն�ʱҲ��������
	 TF0 = 0;
	}
	void timer1ms() interrupt 1{
	static char num=0,num1=0;
	num++;
	/*1ms*/
	if(num==100){
		//100ms
		num1++;
	}
	if(num1==1){
		//����һ��
		tim3--;
		num=0;
		num1=0;
	}
	if(tim3==0){
		if(tim2>0){
		tim3=60;
		tim2--;}
		if(tim2==0){
			if(tim1>0){
				tim1--;
				tim2=60;
			}
		}	
	}
	if(tim2==0){
		if(tim1>0){
		tim2=60;
		tim1--;	   }
	}
	if(tim1==0&&tim2==0&&tim3==0){
		//���˼�ʱ
	   	buz = 0;
		delay(20);		 //������	
		TR0 = 0; //�Ѷ�ʱ�ص�
	}
	}
void main(){	
	inittimer0();
	init_ds1302();
	Rtem();
	delay1ms(500);		 		//��ʱ�䶼�¶�
	write_ds1302(0x8E,0x00);	   //��д����
	ds1302_setTime();
	while(1){
		buz = 1;
		key();
		butAck();
		showAll();						 
	  	if(tim1||tim2||tim3){
			if(timflag){ //������ʱ��
				TR0 = 1; 
			}	
		}
	}
}