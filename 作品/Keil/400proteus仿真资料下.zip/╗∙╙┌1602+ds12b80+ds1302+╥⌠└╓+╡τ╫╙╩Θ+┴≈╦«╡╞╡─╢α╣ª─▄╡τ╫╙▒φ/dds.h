void detect();
uchar i,flag,key,sum;
void detect();
void book();
void page(uchar k);
uchar move[4],set[4],timego[3],ringgo[3];
uchar ring_song;
void alamn();
void time_set();
void timeup();
void music();
#define time_add 0x80
#define alamn_add 0xc0
