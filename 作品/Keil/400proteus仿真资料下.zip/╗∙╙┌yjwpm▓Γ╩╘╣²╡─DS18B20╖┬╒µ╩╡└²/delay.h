#ifndef	__DELAY__H
#define	__DELAY__H

void delay_us(void);
void delay_nus(unsigned int t);
void delay_ms(void);
void delay_nms(unsigned int t);

#endif
