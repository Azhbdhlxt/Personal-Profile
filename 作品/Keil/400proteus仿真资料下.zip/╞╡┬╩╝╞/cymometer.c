//*******************************
//**********����ߣ�������********
//**********��ӭ����ָ��**************
//********************************
#include <REGX52.H>
#include<stdio.h>
#include<math.h>
#include"adc0832.h"
#include "LCD1602.h"
#define uchar unsigned char
#define uint unsigned int
sbit  clr=P3^0;
sbit  gate=P3^1;
sbit  turn=P3^7;
sbit  U_turn=P3^2;
uint  num=0;
uint  peak_value=0;
float Upp=0;
uchar wave=1,pulse=1;
uint j=0,counter=0;
unsigned long int Hight_byte=0,Low_byte=0;
//ms��ʱ------------------------------	
void delay_ms(uint z)
{
  uint x;
  uchar y;
  for(x=0;x<z;x++)
      for(y=0;y<110;y++) ;
}
 //1s��ʱ------------------------------
void delay_1s(void)	    
{
    uchar h,i,j,k;
    for(h=5;h>0;h--)
    for(i=4;i>0;i--)
    for(j=116;j>0;j--)
    for(k=214;k>0;k--);
}


 //��ʱ����	��ʼ��----------------------------------
void CT_init()	      
{

	TMOD = 0x25;				// T0������T1��ʱ
   	TH0 = 0x00;	
	TL0 = 0x00;
	TH1 = 0x06;
	TL1 = 0x06;
	clr=1;
	clr=0;
	gate=0;
	gate=1;
    ET0 = 1;
	ET1 = 1;
	EA  = 1;
    TR0 = 1;
	TR1 = 1;
}

//������--------------------------------------
void main()
{	 
     
	 unsigned long fre=0;
     bit mode=0;
   	 uchar buff[10];
 	 uint temp=0;
	 LCD_Initial();
	 CT_init();
	 GotoXY(0,0);
	 Print("Welcome to use ") ;
	 GotoXY(0,1);
	 Print("Please Wating...");
     delay_1s();
	 LCD_Write(LCD_COMMAND,LCD_CLEAR_SCREEN); 
	 while(1){

	   if(turn==0){	
	         delay_ms(5);
	        if(turn==0)	{
			   while(turn==0);
	            mode=~mode;LCD_Write(LCD_COMMAND,LCD_CLEAR_SCREEN); 
				}
	   	   	   }
     		    temp=vollage(0);
				if(temp>peak_value)
	   	       peak_value=temp; 
			   if(temp>peak_value>>3&&temp<peak_value>>1) pulse=0;
			    
				 if(mode==0){
				fre=(Hight_byte*256)+Low_byte;
				if(fre==0){	GotoXY(0,0);Print("F= 0000000000 Hz");	GotoXY(0,1);Print("F= 0000000000 Hz"); 	}
				else{		
			 	GotoXY(0,0);Print("F=            Hz");sprintf(buff,"%ld",fre);GotoXY(2,0);Print(buff);
				GotoXY(0,1);Print("P=            ms");sprintf(buff,"%0.6f",1000.0/fre);GotoXY(2,1);Print(buff);	} 
			  }
		

	   else{   
	   	sprintf(buff,"%bd",wave);
	   GotoXY(0,0);
       Print(buff);
	   sprintf(buff,"Upp=%0.3fV",Upp);
	   GotoXY(0,1);
       Print(buff);
	      
	   }
  	  
	 }
	 	
}

/*--------------------------------------------------------------*/
//������T0�жϷ������
void T0_counter(void) interrupt 1 using 1
{

}


/*--------------------------------------------------------------*/
//��ʱ��T1�жϷ������
void T1_timer(void) interrupt 3 using 3
{	  
	  
      if(num==3999){
	   gate=0;
	   TR0=0;TR1=0;
	   Hight_byte=TH0*256+TL0;
	   Low_byte=P1;
	   Upp=peak_value/100.0;
	   peak_value=0;
	   wave=pulse;
	   pulse=1;
	   clr=1;
	   clr=0;
   	   TH0 = 0x00;	
	   TL0 = 0x00;
	   TH1 = 0x06;
	   TL1 = 0x06;
	   num=0;
	   gate=1;
	   TR0=1;TR1=1;
	  }
	   else num++;
}
