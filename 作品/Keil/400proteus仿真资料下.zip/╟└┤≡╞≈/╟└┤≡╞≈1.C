#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
uchar code1[9]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f};
sbit key1=P3^0;
sbit key2=P3^1;
sbit key3=P3^2;
sbit key4=P3^3;
sbit key5=P3^4;
sbit key6=P3^5;
sbit key7=P3^6;
sbit key8=P3^7;
sbit keep=P2^0;
sbit key9=P2^2;
void delay(uint t) //��ʱ����
{
 uint j;
 for(;t>0;t--)
 for(j=121;j>0;j--);
}
void display(uchar i)//�������ʾ
{
 switch(i)
 { 
  case 0:P1=code1[0];break;
  case 1:P1=code1[1];break;
  case 2:P1=code1[2];break;
  case 3:P1=code1[3];break;
  case 4:P1=code1[4];break;
  case 5:P1=code1[5];break;
  case 6:P1=code1[6];break;
  case 7:P1=code1[7];break;
  case 8:P1=code1[8];break;
  default:break; 
 }
}

void key() //����ɨ�裬�ж��ĸ�������
{
 uchar n;
  n=0;	
  display(n);
    keep=1;
	 if(key1==0)
	 {
	  delay(5);
	  if(key1==0)
		  {
		    n=1;
		    display(n);
			while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			}
		  }		   
		  while(!key1);
		  delay(5);
		 
	 }
	 if(key2==0)
	 {
		  delay(5);
		  if(key2==0)
		  {
			   n=2;
			   display(n);
			   while(1)
			   {
			   keep=0;			 //����������
			   delay(500);
			   keep=1;
			   delay(500);
			    if(key9==0)
				{
				 delay(5);
				 if(key9==0)
				 {
				    keep=1;
				    n=0;	
	                display(n);
				     while(1)return;
				 }
					 while(!key9);
				     delay(5);
					 while(1);    
					}
				} 
			  }	 
			  while(!key2);
			  delay(5);
	 }	  
	 if(key3==0)
	 {
		  delay(5);
		  if(key3==0)
		  {
			   n=3;
			   display(n);
			    while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			}
		  }					
		  while(!key3);
		  delay(5);	 
	 }
	 if(key4==0)
	 {
		  delay(5);
		  if(key4==0)
		  {
			   n=4;
			   display(n);
			   while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			} 
		  }					
		  while(!key4);
		  delay(5);	 
	 }		
	 if(key5==0)
	 {
		  delay(5);
		  if(key5==0)
		  {
			   n=5;
			   display(n);
			   while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			}
		  }					
		  while(!key5);
		  delay(5);	 
	 }
	 if(key6==0)
	 {
		  delay(5);
		  if(key6==0)
		  {
			   n=6;
			   display(n);
			   while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			}
		  }					
		  while(!key6);
		  delay(5); 
	 }	
	  if(key7==0)
	 {
		  delay(5);
		  if(key7==0)
		  {
			   n=7;
			   display(n);
			   while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			}
		  }					
		  while(!key7);
		  delay(5);	 
	 }	
	 if(key8==0)
	 {
		  delay(5);
		  if(key8==0)
		  {
			   n=8;
			   display(n);
			   while(1)
			{
			keep=0;			 //����������
			delay(500);
			keep=1;
			delay(500);
			 if(key9==0)
			{
			 delay(5);
			 if(key9==0)
			 {
			    keep=1;
			    n=0;	
                display(n);
			  while(1)return;
			 }
			 while(!key9);
		     delay(5);
			 while(1);    
			}
			}
		  }					
		  while(!key8);
		  delay(5);	 
	 }	
}
void main()
{
   while(1)
   {
   	key();
   }
}  





