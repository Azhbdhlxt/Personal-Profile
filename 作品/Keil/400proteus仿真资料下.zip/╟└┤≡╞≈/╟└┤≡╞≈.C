#include<reg51.h>
#define uchar unsigned char
#define uint unsigned int
uchar code1[]={~0x3F,~0x06,~0x5B,~0x4F,~0x66,~0x6D,~0x7D,~0x07,~0x7F};
sbit key1=P1^0;
sbit key2=P1^1;
sbit key3=P1^2;

void delay(uint t)
{
 uint j;
 for(;t>0;t--)
 for(j=19;j>0;j--);
}
void display(uchar i)
{
 switch(i)
 {
  case 0:P2=code1[0];break;
  case 1:P2=code1[1];break;
  case 2:P2=code1[2];break;
 } 
}

void key()
{
 uchar i;
 if(key1==1)
 {
  delay(10);
  if(key1==1)
  {
   delay(10);
   i=0;
   display(i);
  }
 }
  while(key1!=1);
  delay(10);
  if(key2==1)
 {
  delay(10);
  if(key2==1)
  {
   delay(10);
   i=1;
   display(i);
  }
 }
  while(key2!=1);
  delay(10);
  if(key3==1)
 {
  delay(10);
  if(key3==1)
  {
   delay(10);
   i=2;
   display(i);
  }
 }
  while(key3!=1);
  delay(10);
  while(1);
}
void main()
{
 while(1)
 {
  key();
 }
}  