#include "main.h"
#include "delay.h"
//#include "horse.h"
#include "lcd.h"
//#include "ad.h"
//#include "init.h"
//#include "number.h"
//#include "usart.h"
#include <iom16.h> 

//#include <macros.h>


