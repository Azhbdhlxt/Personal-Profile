#ifndef MAIN_H
#define MAIN_H

#define ENABLE_BIT_DEFINITIONS





#ifdef MAIN_C
///

#else
//extern unsigned char table[10];
#endif

#endif
