#include "main.h"
#include "delay.h"
//#include "horse.h"
#include "lcd.h"
//#include "ad.h"
//#include "init.h"
//#include "number.h"
#include "usart.h"
//#include "t6963.h"
#include "dot.h"
#include <avr/signal.h>
#include <avr/interrupt.h>
#include <avr/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include "TWI_Master.h"



