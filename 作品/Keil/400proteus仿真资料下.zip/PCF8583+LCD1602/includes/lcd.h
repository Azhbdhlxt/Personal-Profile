// ************************************************
// *** LCD_4BIT Driver V1.0 ***
// *** LCD.H ***
// ************************************************
/* LCD data bus, 4 bit mode */
// *** LCD Function *** //
//#pragma used+
#ifndef LCD_H
#define LCD_H
#if defined LCD_C
void init_usart(void);
int usart_putchar(char);
void Init_LCD(void);
void LCD_WriteControl (unsigned char CMD);
void LCD_Display_Off(void);
void LCD_Display_On(void);
void LCD_Clear(void);
void LCD_Home(void);
void LCD_Cursor(char row, char column);
void LCD_Cursor_On(void);
void LCD_Cursor_Off(void);
void LCD_DisplayCharacter(char Char);
void LCD_DisplayString_F(char row, char column, unsigned char const *string);
void LCD_DisplayString(char row, char column, unsigned char *string);
#else
extern void init_usart(void);
extern int usart_putchar(char);
extern void Init_LCD(void);
extern void LCD_WriteControl (unsigned char CMD);
extern void LCD_Display_Off(void);
extern void LCD_Display_On(void);
extern void LCD_Clear(void);
extern void LCD_Home(void);
extern void LCD_Cursor(char row, char column);
extern void LCD_Cursor_On(void);
extern void LCD_Cursor_Off(void);
extern void LCD_DisplayCharacter(char Char);
extern void LCD_DisplayString_F(char row, char column, unsigned char const *string);
extern void LCD_DisplayString(char row, char column, unsigned char *string);
#endif
#endif
//#pragma used-
