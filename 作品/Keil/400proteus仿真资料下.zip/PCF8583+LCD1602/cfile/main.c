/*****************************************************************************
*
* Atmel Corporation
*
* File              : main.c
* Compiler          : GCC
* Date              : 2005-12-14
* Updated by        : $Author: mc$
* Supported devices : All devices with a TWI module can be used.
*                     The example is written for the ATmega16
*
* AppNote           : AVR315 - TWI Master Implementation
*
* Description       :
*
****************************************************************************/
#define MAIN_C

#include "includes.h"

unsigned char messageBuf[6];

extern unsigned char TWI_buf[ TWI_BUFFER_SIZE ];    // Transceiver buffer

unsigned char time[5];
unsigned char oldsec;

char number[10] = {'0','1','2','3','4','5','6','7','8','9'};

#define TWI_GEN_CALL         0x00  // The General Call address is 0

// Sample TWI transmission commands
#define SLA_W 0xA0      //PCF8583д��ַ
#define SLA_R  0xA1     //PCF8583����ַ

// Sample TWI transmission states, used in the main application.
#define SEND_DATA             0x01
#define REQUEST_DATA          0x02
#define READ_DATA_FROM_BUFFER 0x03

unsigned char TWI_Act_On_Failure_In_Last_Transmission ( unsigned char TWIerrorMsg )
{
// A failure has occurred, use TWIerrorMsg to determine the nature of the failure
// and take appropriate actions.
// Se header file for a list of possible failures messages.

// Here is a simple sample, where if received a NACK on the slave address,
// then a retransmission will be initiated.

  if ( (TWIerrorMsg == TWI_MTX_ADR_NACK) | (TWIerrorMsg == TWI_MRX_ADR_NACK) )
    TWI_Start_Transceiver();

  return TWIerrorMsg;
}



void BCDtoAscii(unsigned char BCDdata)    //��BCD��ת��Ϊ�ַ������ڴ�����ʾ
{
    unsigned char AsciiData[2];
    unsigned char temp;
    temp = BCDdata;
    AsciiData[0] = (((temp& 0xf0) >> 4) + 0x30);
    temp &= 0x0f;
    AsciiData[1] = temp + 0x30;
    //PutStr(AsciiData);
    PutChar(AsciiData[0]);
    PutChar(AsciiData[1]);
    LCD_DisplayCharacter(AsciiData[0]);
    LCD_DisplayCharacter(AsciiData[1]);
}

void ShowTime(unsigned char *data)
{
    unsigned char sec,min,hour;
    unsigned char newsec;
    sec  = data[1];
    min  = data[2];
    hour = data[3];
    newsec = sec;
    if(newsec != oldsec)   //�ж�ʱ����û�и���
    {
        PutStr("PCF8583ʱ��Ϊ: ");
        LCD_Cursor(2,2);
        BCDtoAscii(hour);
        PutChar(':');
        LCD_DisplayCharacter(':');
        BCDtoAscii(min);
        PutChar(':');
        LCD_DisplayCharacter(':');
        BCDtoAscii(sec);
        PutChar('\n');
        oldsec = newsec;
    }
}

int main( void )
{

    int i;
    DDRA = 0xFF;
    PORTA = 0xff;
    UsartInit();                //USART��ʼ��
    TWI_Master_Initialise();   //TWI��ʼ��
    Init_LCD();
    PutStr("TWI��ʼ���ɹ�!\n");
    SREG |= (1<<7);            //Enable_interrupt
    messageBuf[0] = SLA_W;
    messageBuf[1] = 0x00;     //���ƼĴ�����ַ
    messageBuf[2] = 0x00;
    delay_nms(1000);
    TWI_Start_Transceiver_With_Data( messageBuf, 3 );
    PutStr("��ʼ��ȡPCF8583��ʱ��\n");
    delay_nms(1000);
    LCD_DisplayString(1,1,"PCF8583 time is:");
    while(1)
    {
        delay_nms(10);
        messageBuf[0] = SLA_W;
        messageBuf[1] = 0x02;
        TWI_Start_Transceiver_With_Data( messageBuf, 2 );
        delay_nms(200);
        messageBuf[0] = SLA_R;
        TWI_Start_Transceiver_With_Data( messageBuf, 4 );
        delay_nms(1);
        for(i=1;i<4;i++)
        {
            time[i] = TWI_buf[i]&0x7f;   //�������λ
        }
        ShowTime(time);
    }
}

