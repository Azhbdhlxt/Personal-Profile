#include "1602.H"
#include "DS18B20.H"

TEMPDATA m_TempData;

//���ݴ����ӳ���
void DataProcess()
{
	m_TempData = ReadTemperature();
	if (m_TempData.btNegative) DisplayOne(1, 6, '-', 0);
	else DisplayOne(1, 6, m_TempData.btThird, 1);
	DisplayOne(1, 7, m_TempData.btSecond, 1);
	DisplayOne(1, 8, m_TempData.btFirst, 1);
	DisplayOne(1, 10, m_TempData.btDecimal, 1);
}

void main()
{
	//GetROMSequence();
	Clear();
	Init();
	DisplayString(0, 0, "  Temperature");
	DisplayOne(1, 9, '.', 0);
	while (1) DataProcess();
}

