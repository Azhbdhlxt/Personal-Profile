/*****************************************************
This program was produced by the
CodeWizardAVR V1.24.6 Professional
Automatic Program Generator
� Copyright 1998-2005 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com
e-mail:office@hpinfotech.com

Project : 
Version : 
Date    : 2005-11-22
Author  : F4CG                            
Company : F4CG                            
Comments: 


Chip type           : ATmega8
Program type        : Application
Clock frequency     : 1.000000 MHz
Memory model        : Small
External SRAM size  : 0
Data Stack size     : 256
*****************************************************/
#define KEY PINC.0
#define PWMA PORTB.3 //17�Ž� 
#define PWMB PORTB.4 //18�Ž� 
#include <mega8.h>
#include <delay.h>
#include <math.h>

unsigned int m=0;
unsigned char xiangxian=0; 
bit INIT2=0; //�ж��Ƿ�����2�Ѿ���ʼ����
bit INIT3=0;
bit INIT4=0;
 /*����Ϊ�ĸ������д�������������Ϊ45��ƽ��Ϊ255�νǶ�*/
inline panduan()
{
 if(m<=255)
         { 
         xiangxian=1;
         }
 else if((m>255)&&(m<511))
        {
         xiangxian=2;
         if(m==256)
         {
            INIT2=1;
            PWMA=0;
            OCR1A=0x00;
            OCR1B=0xff;
            PWMB=1;
         } 
        }
 else if((m>=511)&&(m<767))
         {
           xiangxian=3;
          
         }
else if((m>=767)&&(m<1024))
{
 xiangxian=4;
}
else if(m>1024)
  {
   m=0;
  }
}

void xiangxian1(unsigned char degree)
{ 
PWMA=0;
PWMB=0;
OCR1BL=m;
OCR1AL=255-m;
}


void xiangxian2(unsigned char degree)
{ unsigned char temp;
  temp=m-255;
  OCR1AL=temp;
  OCR1BL=temp;
       
  
}


void xiangxian3(unsigned char degree)
{
  unsigned char temp;
  temp=m-511;
  PWMA=1;
  PWMB=1;
  OCR1BL=255-temp;
  OCR1AL=temp;
}


void xiangxian4(unsigned char degree)
{unsigned char temp=0;
temp=m-767;
PWMA=1;
PWMB=0;
OCR1BL=255-temp;
OCR1AL=255-temp;

}





 /*�Ƕȼ��㺯������������ڸ��������нǶȶ�Ӧ��PWM���*/  
void SET_ANGLE( unsigned char degree)  
{
 switch (xiangxian)
 {
  case 1: xiangxian1(degree);break;
  
  case 2: xiangxian2(degree);break;
  
  case 3: xiangxian3(degree);break;
  
  case 4: xiangxian4(degree);break;
  
  default:break;
  
 
 
 }
 

}                        

void main(void)
{
 unsigned char temp; 
 unsigned char xiangxian=0;

// Declare your local variables here

PORTB=0x187;
DDRB=0x1e;

// Port C initialization
// Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State6=T State5=T State4=T State3=T State2=T State1=T State0=P 
PORTC=0x01;
DDRC=0x00;

// Port D initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=Out Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=0 State1=T State0=T 
PORTD=0x00;
DDRD=0x04;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
TCCR0=0x00;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 1000.000 kHz
// Mode: Fast PWM top=01FFh
// OC1A output: Inverted
// OC1B output: Inverted
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0xF1;
TCCR1B=0x01;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
MCUCR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;
 PWMA=0;
 PWMB=0;
OCR1AL=0xff;
OCR1BL=0x00;


while (1)
      {
       if(KEY==0)
       {
        delay_ms(20);
        if(KEY==0)
        { 
         m=m+1;
         panduan();
         SET_ANGLE(m);
         PORTD.2=!PORTD.2;
        }
        
       }
       
       
       
      };
}
