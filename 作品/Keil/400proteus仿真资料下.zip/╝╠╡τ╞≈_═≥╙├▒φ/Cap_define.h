void Tmie0_init(void);
void Cap_disp_init(void);
void Cap_measure(void);








