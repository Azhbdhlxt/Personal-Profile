#include<reg52.h>
#include"Delay.h" 
#include<KEY_FUNCTION_DEFINE.H>
#include<measure_define.h>
#include"AD.h"
#include"LCD.h"
extern uchar disp_value[5];
extern uchar key_number;
extern uchar code  DC_disp3[];
uchar code CC_disp[]="Current Measure  ";
uchar code CC_disp2[]="value=        ";
void Circuit_measure(void)
{       uchar  ADTemp,num;
		float ValueTemp;
		WriteCom(0x01);						//����
     	WriteCom(0x80);				 	    //��ʾ���������ַ���
	 for(num=0;CC_disp[num]!='\0';num++)	 
		{WriteData(CC_disp[num]);			 
		Delay(10);	}																	  
		WriteCom(0x80+0x40);				 				 //��ʾ
	 for(num=0;CC_disp2[num]!='\0';num++)
		{WriteData(CC_disp2[num]);			 
			Delay(10);	}
	do{							                    //	ѡ��2A��
		     	s1=0;
			    s2=0;
			    s3=1;
				Delay(5);
		ADTemp=ADSample(Circuit_adder);		   //AD��ʼ����
	if(ADTemp>253)
		{ WriteCom(0x80+0x46);										//��ʾ
		for(num=0;DC_disp3[num]!='\0';num++)
		{WriteData(DC_disp3[num]);
			Delay(50);} 
		}	 
	else
		{ValueTemp=ValueConver(ADTemp);		         //
		 ValueTemp=ValueTemp*1000;			               //		    	
		 FloatToChar(ValueTemp);				            //�����ѹֵת��Ϊ�ַ�������
	      WriteCom(0x80+0x46);				 //��ʾ�ĵ�ַ
		 for(num=0;num<5;num++)
		{WriteData(disp_value[num]);			  //��ʾ��ֵ
			Delay(50);	}
		 WriteData('m');
		 WriteData('A');	}									  			
		}  while((ADTemp>24)&&(key_number==3));	 //����ֵ����200mA

		do{										  //ѡͨ200mAͨ��
		    	s1=0;
			    s2=1;
			    s3=0;
				Delay(5);						  //������ֵ
		ADTemp=ADSample(Circuit_adder);
		ValueTemp=ValueConver(ADTemp);
		ValueTemp=ValueTemp*100;					 
		FloatToChar(ValueTemp);
	//	LcdDisplayValue(Value);
		WriteCom(0x80+0x46);
		for(num=0;num<5;num++)
		{
			WriteData(disp_value[num]);
			Delay(50);	
		}
		WriteData('m');	
		WriteData('A');			 
	}  while((ADTemp>24)&&(ADTemp<253)&&(key_number==3));	//������ѹֵ����20mAС��200mA

	   	do{
		    	s1=1;
			    s2=0;
			    s3=0;
				Delay(5);
		ADTemp=ADSample(Circuit_adder);
		ValueTemp=ValueConver(ADTemp);
		ValueTemp=ValueTemp*10;
		FloatToChar(ValueTemp);
//	  LcdDisplayValue(Value);
   	WriteCom(0x80+0x46);
		for(num=0;num<5;num++)
		{
			WriteData(disp_value[num]);
			Delay(50);	
		}
		WriteData('m');	
		WriteData('A');					
	}  while((ADTemp<253)&&(key_number==3));//������ѹֵС��20mA    
	
}	