#include<reg52.h>
#include <key_function_define.h>
#include<measure_define.h>
















